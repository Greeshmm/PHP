<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
 <center> 
<table bgcolor=white border=0 width=100% height=6%>
<tr><td>
<table>
</table>
<td><table bgcolor=white border=0 width=80%>
        <td align=center width=30% font color=red size=5><a href=logout.php style="color:red; text-decoration:none;"><b>Logout</b>
</table>
</table>
 </center>

